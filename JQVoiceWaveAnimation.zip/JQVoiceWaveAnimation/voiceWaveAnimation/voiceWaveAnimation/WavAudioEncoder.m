//
//  WavAudioEncoder.m
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import "WavAudioEncoder.h"

typedef struct {
    char ChunkID[4]; // 'RIFF'
    int32_t ChunkSize; // total size
    char Format[4]; // 'WAVE'

    char Subchunk1ID[4]; // 'fmt ' */
    int32_t Subchunk1Size; // fmt size */
    int16_t AudioFormat; // 1 for lpcm */
    int16_t NumChannels; // 1 or 2*/
    int32_t SampleRate; // 8000~48000 */
    int32_t ByteRate; // SampleRate * BitsPerSample / 8 */
    int16_t BlockAlign; //
    int16_t BitsPerSample; // 8, 16, 24, 32

    char Subchunk2ID[4]; // 'data'
    int32_t Subchunk2Size; // pcm data size
} WavFileHeader;

@implementation WavAudioEncoder

- (NSInteger)headerDataLength {
    return sizeof(WavFileHeader);
}

- (NSData *)headerDataForPacketLength:(NSUInteger)packetLength {
    WavFileHeader *packet = (WavFileHeader *)malloc(sizeof(WavFileHeader));

    int32_t headerLength = 44;
    int32_t chunkSize = headerLength + (int32_t)packetLength;
    int16_t numberOfChannels = 1;
    int32_t sampleRate = 16000;
    int16_t bitsPerSample = 16;
    int32_t byteRate = sampleRate * bitsPerSample / 8;

    packet->ChunkID[0] = 'R';
    packet->ChunkID[1] = 'I';
    packet->ChunkID[2] = 'F';
    packet->ChunkID[3] = 'F';

    packet->ChunkSize = chunkSize;

    packet->Format[0] = 'W';
    packet->Format[1] = 'A';
    packet->Format[2] = 'V';
    packet->Format[3] = 'E';

    packet->Subchunk1ID[0] = 'f';
    packet->Subchunk1ID[1] = 'm';
    packet->Subchunk1ID[2] = 't';
    packet->Subchunk1ID[3] = '\x20';
    packet->Subchunk1Size = 16;
    packet->AudioFormat = 1; // lpcm
    packet->NumChannels = numberOfChannels;
    packet->SampleRate = sampleRate;
    packet->ByteRate = byteRate;
    packet->BlockAlign = numberOfChannels * bitsPerSample / 8;
    packet->BitsPerSample = bitsPerSample;

    packet->Subchunk2ID[0] = 'd';
    packet->Subchunk2ID[1] = 'a';
    packet->Subchunk2ID[2] = 't';
    packet->Subchunk2ID[3] = 'a';
    packet->Subchunk2Size = (int32_t)packetLength;

    return [NSData dataWithBytesNoCopy:packet length:headerLength freeWhenDone:YES];
}

@end
