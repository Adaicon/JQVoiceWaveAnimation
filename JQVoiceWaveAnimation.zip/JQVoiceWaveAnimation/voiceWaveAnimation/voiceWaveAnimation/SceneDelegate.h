//
//  SceneDelegate.h
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

