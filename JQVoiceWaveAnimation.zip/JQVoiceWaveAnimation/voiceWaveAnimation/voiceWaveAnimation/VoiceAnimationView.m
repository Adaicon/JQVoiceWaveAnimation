//
//  VoiceAnimationView.m
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import "VoiceAnimationView.h"
#import <Foundation/Foundation.h>

static const NSInteger numOfItems = 100;
static const double betweenSpace = 4.0;
static const double lineWidth = 1.0;
static const double ceilSpace = betweenSpace + lineWidth;
static const double originHeight = 1.0;
static const double maxHeight = 40.0;
static const double minHeight = 2.0;
static const double topSpace = 16.0;
static const double selfHeight = 56.0;

@interface VoiceAnimationView ()

@property (nonatomic, strong) NSMutableArray * levels;
@property (nonatomic, strong) NSMutableArray * itemLayers;
@property (nonatomic, strong) CADisplayLink *link;
@property (nonatomic, assign) BOOL clear;
@property (nonatomic, assign) BOOL isStop;
@property (nonatomic, assign) NSInteger moveNum;

@end

@implementation VoiceAnimationView

- (instancetype)init {
    if (self = [super init]) {
        [self config];
    }
    return self;
}

- (void)config {
    self.levels = [NSMutableArray array];
    self.itemLayers = [NSMutableArray array];
    for (NSInteger i = 0 ; i < numOfItems; i++) {
        [self.levels addObject: @(0)];
        [self.itemLayers addObject:[self createItem:0.0]];
    }
    [self.itemLayers addObject:[self createItem:originHeight]];
    self.backgroundColor = UIColor.blackColor;
}

- (void)addLevel: (double)level {
    if (self.isStop) { return; }
    
    double height = (level + 45) / 45 * maxHeight;
    // 确保1-40
    height = fmax(height, minHeight); 
    height = fmin(height, maxHeight);
    [self.levels addObject: @(height)];
    [self.levels removeObjectAtIndex: 0];
    self.moveNum = 0;
}

- (void)startWave {
    self.isStop = NO;
    if (self.clear) {
        [self.itemLayers enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [self.layer addSublayer:obj]; 
        }];
    } 
    [self updateItems];
    [self createDisplayLink];
    self.clear = NO;
}

- (void)stopWave {
    [self removeDisplayLink];
    self.isStop = YES;
}

- (void)clearWave {
    [self stopWave];
    [self.itemLayers enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperlayer];
    }];;
    [self.levels enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj = 0;
    }];
    
    self.clear = YES;
}

- (CAShapeLayer *)createItem: (double)level {
    CAShapeLayer *itemLine = [CAShapeLayer layer];
    itemLine.lineCap = kCGLineCapButt;
    itemLine.strokeColor = UIColor.clearColor.CGColor;
    itemLine.fillColor = UIColor.clearColor.CGColor;
    itemLine.strokeColor = UIColor.greenColor.CGColor;
    itemLine.lineWidth = lineWidth;
    [self.layer addSublayer: itemLine];
    return itemLine;
}

- (void)updateItems {
    double selfWidth = UIScreen.mainScreen.bounds.size.width;
    
    UIGraphicsBeginImageContext(CGSizeMake(UIScreen.mainScreen.bounds.size.width, 56));

    double offset = self.moveNum;
    
    // 末尾的高度始终为1.0
    double lineTop = (selfHeight - topSpace - originHeight) / 2 + topSpace;
    UIBezierPath *linePath = [UIBezierPath bezierPath];
    [linePath moveToPoint:CGPointMake(selfWidth - lineWidth - offset, lineTop)];
    [linePath addLineToPoint:CGPointMake(selfWidth - lineWidth - offset, lineTop + originHeight)];
    CAShapeLayer *item = self.itemLayers[numOfItems];
    item.path = linePath.CGPath;
            
    [self.levels enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        double rightX = selfWidth - lineWidth - offset - (numOfItems - idx) * (betweenSpace + lineWidth);
        double lineTop = (selfHeight - topSpace - [obj intValue]) / 2 + topSpace;
        double lineBottom = lineTop + [obj intValue];
        
        UIBezierPath *linePath = [UIBezierPath bezierPath];
        [linePath moveToPoint:CGPointMake(rightX, lineTop)];
        [linePath addLineToPoint:CGPointMake(rightX, lineBottom)];
        CAShapeLayer *item = self.itemLayers[idx];
        item.path = linePath.CGPath;
    }];
    
    self.moveNum += 1;
    UIGraphicsEndImageContext();
    
}

- (void)createDisplayLink {
    self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(updateItems)];
    [self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)removeDisplayLink {
    [self.link invalidate];
    self.link = nil;
}

@end
