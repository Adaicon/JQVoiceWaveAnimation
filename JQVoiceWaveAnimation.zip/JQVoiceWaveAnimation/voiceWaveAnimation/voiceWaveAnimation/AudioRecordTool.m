//
//  AudioRecordTool.m
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import "AudioRecordTool.h"
#import <AVFoundation/AVFoundation.h>
#import "WavAudioEncoder.h"

static const int kNumberBuffers = 3;

@interface AudioRecordTool () {
    // 音频队列
    AudioQueueRef queueRef;
    // buffers数量
    AudioQueueBufferRef buffers[kNumberBuffers];
    // 音频数据格式
    AudioStreamBasicDescription dataformat;
}

@property (nonatomic, assign) SInt64 currPacket;
// 当前录制文件的大小
@property (nonatomic, assign) UInt32 bufferBytesSize;

@property (nonatomic, strong) NSTimer *meterTimer;
@end
@implementation AudioRecordTool

- (instancetype)init {
    if (self = [super init]) {
        [self config];
        [self setupAudioQueue];
    }
    return self;
}

- (void)dealloc {
    AudioQueueDispose(queueRef, true);
}

- (BOOL)record {
    if (self.isRunning) {
        return YES;
    }
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [[AVAudioSession sharedInstance] setActive:true error:nil];
    
    OSStatus status = AudioQueueStart(queueRef, NULL);
    if (status != noErr) {
        NSError *error = [NSError errorWithDomain:NSOSStatusErrorDomain code:status userInfo:nil];
        NSLog(@"start queue failure: %@",[error description]);

        return NO;
    }
    _isRunning = true;
    return  _isRunning;
}

- (void)pause {
    if (!self.isRunning) {
        return;
    }
    OSStatus status = AudioQueuePause(queueRef);
    if (status != noErr) {
        return;
    }
    _isRunning = false;
}

- (void)stop {
    if (self.isRunning) {
        AudioQueueStop(queueRef, true);
        _isRunning = false;
    }
}

- (void)startMeterMonitorWithTimerInterval:(NSTimeInterval)interval block:(void (^)(float))meterBlock {
    if (interval <= 0) {
        return;
    }
    [self _enableMetering:YES];
    // __weak weakSelf = self;
    self.meterTimer = [NSTimer scheduledTimerWithTimeInterval:interval repeats:YES block:^(NSTimer * _Nonnull timer) {
        
        meterBlock(self.meter);
    }];
    [[NSRunLoop mainRunLoop] addTimer:self.meterTimer forMode:NSRunLoopCommonModes];
}

- (void)stopMeterMonitor {
    [self _enableMetering:NO];
    if (self.meterTimer) {
        [self.meterTimer invalidate];
        self.meterTimer = nil;
    }
}

/**
 *   aqData: 自定义数据
 *   inAQ: 调用回调函数的音频队列
 *   inBuffer: 装有音频数据的buffer
 *   timestamp: 当前音频数据的时间戳
 *   inNumPackets: 包数量
 *   inPacketDesc: packt的描述 如果正在录制VBR格式，音频队列会提供此参数的值，在AudioFileWritePackets时可以用到
 */
static void recoderCallBack(void *aqData, AudioQueueRef inAQ, AudioQueueBufferRef inBuffer, const AudioTimeStamp *timestamp, UInt32 inNumPackets, const AudioStreamPacketDescription *inPacketDesc) {
    AudioRecordTool *recoder = (__bridge AudioRecordTool *)aqData;
    
    if (inNumPackets == 0 && recoder->dataformat.mBytesPerPacket != 0) {
        inNumPackets = inBuffer->mAudioDataByteSize / recoder->dataformat.mBytesPerPacket;
    }
    // 包数量大于 0 才处理
    if (inNumPackets > 0) {
        // 获得原始的语音数据
        NSData *audioData = [NSData dataWithBytes:inBuffer->mAudioData length:inBuffer->mAudioDataByteSize];
        if (recoder.audioCaptureBlock) {
            recoder.audioCaptureBlock(audioData);
        }
    }
    
    if (recoder.isRunning) {
        // 入队
        AudioQueueEnqueueBuffer(inAQ, inBuffer, 0, NULL);
    }
}

// 获取AudioQueueBuffer大小
void deriveBufferSize(AudioQueueRef audioQueue, AudioStreamBasicDescription streamDesc, Float64 seconds, UInt32 *outBufferSize) {
    // 音频队列数据大小的上限
    static const int maxBufferSize = 0x50000;
    static const int minBufferSize = 0x4000;
    
    int maxPacketSize = streamDesc.mBytesPerPacket;
    if (maxPacketSize == 0) { // VBR
        UInt32 maxVBRPacketSize = sizeof(maxPacketSize);
        AudioQueueGetProperty(audioQueue, kAudioQueueProperty_MaximumOutputPacketSize, &maxPacketSize, &maxVBRPacketSize);
    }
    // 获取音频数据大小
    Float64 numBytesForTime = streamDesc.mSampleRate * maxPacketSize * seconds;
    if (numBytesForTime < minBufferSize) {
        *outBufferSize = minBufferSize;
    } else if (numBytesForTime > maxBufferSize) {
        *outBufferSize = maxBufferSize;
    } else {
        *outBufferSize = numBytesForTime;
    }
}

#pragma mark - Private
- (void)config {
    dataformat.mSampleRate = 16000.0f;
    dataformat.mFramesPerPacket = 1;
    dataformat.mChannelsPerFrame = 1;
    dataformat.mBitsPerChannel = 16;
    dataformat.mFormatID = kAudioFormatLinearPCM;
    dataformat.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked;
    dataformat.mBytesPerFrame = (dataformat.mBitsPerChannel / 8) * dataformat.mChannelsPerFrame;
    dataformat.mBytesPerPacket = dataformat.mBytesPerFrame * dataformat.mFramesPerPacket;
}

- (void)setupAudioQueue {
    self.currPacket = 0;
    
    // 创建Audio Queue
    OSStatus status = AudioQueueNewInput(&dataformat, recoderCallBack, (__bridge void *)self, NULL, NULL, 0, &queueRef);
    if (status != noErr) {
        [self safeErrorBlock:[NSString stringWithFormat:@"create new input queue error - %d",status]];
    }
    
    // 设置音频队列数据大小
    deriveBufferSize(queueRef, dataformat, 0.05, &_bufferBytesSize);
    
    // 为Audio Queue准备指定数量的buffer
    for (int i = 0; i < kNumberBuffers; i++) {
        AudioQueueAllocateBuffer(queueRef, self.bufferBytesSize, &buffers[i]);
        AudioQueueEnqueueBuffer(queueRef, buffers[i], 0, NULL);
    }
}

- (void)_enableMetering:(BOOL)enable {
    UInt32 trueValue = enable;
    _meteringEnabled = enable;
    AudioQueueSetProperty(queueRef, kAudioQueueProperty_EnableLevelMetering, &trueValue, sizeof(UInt32));
}

- (void)safeErrorBlock:(NSString *)message {
    if (self.errorBlock) {
        self.errorBlock(message);
    }
}

#pragma mark - Getter
- (float)meter {
    if (!queueRef)
        return 0.0f;
    if (!self.isMeteringEnabled)
        return 0.0f;
    UInt32 size;
    AudioQueueGetPropertySize(queueRef, kAudioQueueProperty_CurrentLevelMeterDB, &size);
    AudioQueueLevelMeterState meterState;
    AudioQueueGetProperty(queueRef, kAudioQueueProperty_CurrentLevelMeterDB, &meterState, &size);
    return meterState.mAveragePower;
}
@end
