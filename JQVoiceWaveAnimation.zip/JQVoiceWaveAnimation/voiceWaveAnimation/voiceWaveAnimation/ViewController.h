//
//  ViewController.h
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

