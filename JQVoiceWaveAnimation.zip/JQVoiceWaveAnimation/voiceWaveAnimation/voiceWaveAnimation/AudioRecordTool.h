//
//  AudioRecordTool.h
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AudioRecordTool : NSObject

@property (nonatomic, assign, readonly) BOOL isRunning;

@property (nonatomic) NSTimeInterval meterTimerInterval;

/* turns level metering on or off. default is off. */
@property (nonatomic, getter=isMeteringEnabled) BOOL meteringEnabled; 

// -160 - 0
@property (nonatomic, assign) float meter;

@property (nonatomic, copy) void(^errorBlock)(NSString *errTips);

@property (nonatomic, copy) void (^audioCaptureBlock)(NSData *audioData);

- (BOOL)record;

- (void)pause;

- (void)stop;

- (void)startMeterMonitorWithTimerInterval:(NSTimeInterval)interval block:(void(^)(float))meterBlock;

- (void)stopMeterMonitor;

- (void)deleteAudioFile;

@end

NS_ASSUME_NONNULL_END
