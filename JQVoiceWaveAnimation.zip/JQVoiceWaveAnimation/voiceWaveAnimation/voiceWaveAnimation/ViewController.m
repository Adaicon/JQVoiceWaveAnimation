//
//  ViewController.m
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import "ViewController.h"
#import "AudioRecordTool.h"
#import "VoiceAnimationView.h"

@interface ViewController ()

@property (nonatomic, strong) UIButton *startBtn;
@property (nonatomic, strong) UIButton *pauseBtn;
@property (nonatomic, strong) AudioRecordTool *recorder;
@property (nonatomic, strong) VoiceAnimationView *animationView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupViews];
}

- (void)setupViews {
    [self.view addSubview:self.startBtn];
    [self.view addSubview:self.pauseBtn];
    [self.view addSubview:self.animationView];
    
    self.startBtn.frame = CGRectMake(50, 300, 64, 32);
    self.pauseBtn.frame = CGRectMake(150, 300, 64, 32);
    self.animationView.frame = CGRectMake(0, 500, UIScreen.mainScreen.bounds.size.width, 56);
}


- (UIButton *)startBtn {
    if (!_startBtn) {
        _startBtn = [UIButton new];
        [_startBtn setTitle:@"start" forState:(UIControlStateNormal)];
        _startBtn.backgroundColor = UIColor.blueColor;
        [_startBtn addTarget:self action:@selector(clickStart) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _startBtn;
}

- (UIButton *)pauseBtn {
    if (!_pauseBtn) {
        _pauseBtn = [UIButton new];
        _pauseBtn.backgroundColor = UIColor.blueColor;
        [_pauseBtn setTitle:@"pause" forState:(UIControlStateNormal)];
        [_pauseBtn addTarget:self action:@selector(clickPause) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _pauseBtn;
}

- (void)clickStart {
    [self.recorder stopMeterMonitor];
    [self.animationView stopWave];
    [self.recorder pause]; 
    
    [self.recorder record];
    [self.animationView startWave];
    [self.recorder startMeterMonitorWithTimerInterval:0.1 block:^(float meter) {
        [self.animationView addLevel:meter];
    }];
}

- (void)clickPause {
    [self.recorder pause]; 
    [self.recorder stopMeterMonitor];
    [self.animationView stopWave];
}

- (AudioRecordTool *)recorder {
    if (!_recorder) {
        _recorder = [[AudioRecordTool alloc] init];
    }
    return _recorder;
}

- (VoiceAnimationView *)animationView {
    if (!_animationView) {
        _animationView = [[VoiceAnimationView alloc] init];
    }
    return _animationView;
}

@end
