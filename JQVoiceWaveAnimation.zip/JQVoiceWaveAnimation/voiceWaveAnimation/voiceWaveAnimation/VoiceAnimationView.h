//
//  VoiceAnimationView.h
//  voiceWaveAnimation
//
//  Created by Jieqiong on 2022/2/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VoiceAnimationView : UIView

- (void)addLevel: (double)level;
- (void)startWave;
- (void)stopWave;


@end

NS_ASSUME_NONNULL_END
